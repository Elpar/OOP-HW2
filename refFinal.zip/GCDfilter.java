package homework2;

/*
 * GCDfilter is a filter intended to calculate GCD value of 2 inputs. This class
 * inherits Filter class
 */
public class GCDfilter extends Filter<String> implements Simulatable<String> {
	
	/* Abstraction Function :
	 * GCD filter label represents a String class.
	 * filterDelay of the GCD will be 1.
	 * 0 or more.
	 */
	
	/* Representation Invariant :
	 *	The filter can be connected to 2 input pipes with edges named "a", "b", 
	 *  and 3 output pipes connected with edges  "a", "b", "gcd"
	 */
	
	
	/**
	 * @requires label != 0
	 * @modifies this
	 * @effects  Constructs a new GCDfilter
	 */
	public GCDfilter(String label) {
		super(label);
		setFilterdelay(1);
	}
	
	@Override
	/**
	 * @requires graph != null , timeslice != 0
	 * @modifies this
	 * @effects  simulates the GCDfilter for 1 timeSlice
	 */
	public void simulate(BipartiteGraph<String> graph, double timeSlice) {
		validateGraphInput(graph);
			for (double timeElapsed = 0; timeElapsed + getFilterDelay() <= timeSlice;
						timeElapsed=+getFilterDelay()) {	
			
				String parentA 	= graph.getParentByEdgeLabel(getFilterLabel(), "a");
				String parentB 	= graph.getParentByEdgeLabel(getFilterLabel(), "b");
				String childA 	= graph.getChildByEdgeLabel(getFilterLabel(), "a");
				String childB 	= graph.getChildByEdgeLabel(getFilterLabel(), "b");
				String childGCD = graph.getChildByEdgeLabel(getFilterLabel(), "gcd");
			
				Pipe<String>	inputPipeA 		= (Pipe<String>) graph.getNodeObject(parentA);
				Pipe<String>	inputPipeB		= (Pipe<String>) graph.getNodeObject(parentB);
				Pipe<String>	outputPipeA 	= (Pipe<String>) graph.getNodeObject(childA);
				Pipe<String>	outputPipeB		= (Pipe<String>) graph.getNodeObject(childB);
				Pipe<String>	outputPipeGCD 	= (Pipe<String>) graph.getNodeObject(childGCD);
		
				if ((Integer)inputPipeB.getLastElement() == 0) {
					outputPipeGCD.InjectValue(inputPipeA.removeLastElement());
				}
				else if ((Integer)inputPipeA.getLastElement() < (Integer)inputPipeB.getLastElement()) {
					outputPipeA.InjectValue(inputPipeB.removeLastElement());
					outputPipeB.InjectValue(inputPipeA.removeLastElement());
				}
				else {
					outputPipeA.InjectValue((Integer)inputPipeB.getLastElement());
					outputPipeB.InjectValue((Integer)inputPipeA.removeLastElement() % 
										(Integer)inputPipeB.removeLastElement());
				}	
			}
		
			validateGraphInput(graph);
	}
	
	private void validateGraphInput(BipartiteGraph<String> graph) {
		if (graph == null) {
			throw new IllegalArgumentException("Wrong input - graph is null");
		}
		
		if (graph.getParentsNodes(getFilterLabel()).size() != 2) {
			throw new IllegalArgumentException("Wrong input - GCDfilter should have 2 parents");
		}
		
		if (graph.getChildrenNodes(getFilterLabel()).size() != 3) {
			throw new IllegalArgumentException("GCDfilter should have 3 children");
		}
			
		String parentA 	= graph.getParentByEdgeLabel(getFilterLabel(), "a");
		String parentB 	= graph.getParentByEdgeLabel(getFilterLabel(), "b");
		String childA 	= graph.getChildByEdgeLabel(getFilterLabel(), "a");
		String childB 	= graph.getChildByEdgeLabel(getFilterLabel(), "b");
		String childGCD = graph.getChildByEdgeLabel(getFilterLabel(), "gcd");
	
		Pipe<String>	inputPipeA 		= (Pipe<String>) graph.getNodeObject(parentA);
		Pipe<String>	inputPipeB		= (Pipe<String>) graph.getNodeObject(parentB);
		Pipe<String>	outputPipeA 	= (Pipe<String>) graph.getNodeObject(childA);
		Pipe<String>	outputPipeB		= (Pipe<String>) graph.getNodeObject(childB);
		Pipe<String>	outputPipeGCD 	= (Pipe<String>) graph.getNodeObject(childGCD);
		
		if(inputPipeA 	== null) {
			throw new IllegalArgumentException("GCDfilter should have one parent connected via edge a");
		}
		
		if(inputPipeB 	== null) {
			throw new IllegalArgumentException("GCDfilter should have one parent connected via edge b");
		}
		
		if(outputPipeA 	== null) {
			throw new IllegalArgumentException("GCDfilter should have one child connected via edge a");
		}
		
		if(outputPipeB 	== null) {
			throw new IllegalArgumentException("GCDfilter should have one child connected via edge b");
		}
		
		if(outputPipeGCD == null) {
			throw new IllegalArgumentException("GCDfilter should have one parent connected via edge gcd");
		}
				
	}

}
