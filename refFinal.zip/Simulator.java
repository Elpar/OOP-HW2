package homework2;

import java.util.List;


/*
 * The simulator is a class which simulates three objects:
 * 	Job Objects - objects what will  be in the system
 *  Pipes - will transfer job objects in the system
 *  Filters - Will process the job objects
 */
public class Simulator<Label> {
	 
	/* Abstraction Function :
	 * The simulator contains a bipartite graph which will contain filters as
	 * white nodes and pipes as black nodes.
	 * The timeSlice is defined as the timeSlice of the simulator for Round-Robin
	 * scheduler 
	 */
	
	/* Representation Invariant :
	 * a BipartiteGraph graph which is not null
	 * timeSlice > 0
	 */
	
	 BipartiteGraph<Label> simGraph = new BipartiteGraph<Label>();
	 int timeSlice = 0;
	 
	 /**
	  * @requires timeSlice > 0
	  * @modifies this
	  * @effects  Constructs a new Simulator with timeSlice.
	  */
	 public Simulator(int timeSlice) {
		 this.timeSlice = timeSlice;
		 checkRep ();
	 }
	 
	 /**
	  * @modifies this
	  * @effects  add a new Pipe to simulator's graph
	  */ 
	 public void addPipe(Pipe<Label> pipe) {
		checkRep();
		 if (pipe != null) {
			 Label pipeLabel = pipe.getLabel();
			 simGraph.addBlackNodeWithObject(pipeLabel, pipe);	
		}
		 checkRep();
	 }
	 
	 /**
	  * @modifies this
	  * @effects  add a new Pipe to simulator's graph
	  */
	 public void addFilter(Filter<Label> filter) {
		 checkRep();
		 if (filter != null) {
			 Label filterLabel = filter.getFilterLabel();
			 simGraph.addWhiteNodeWithObject(filterLabel, filter);
		 }
		 checkRep();
	 }
	 
	 /**
	  * @modifies this
	  * @effects  adds an Edge between the parent and child named 
	  * 		  edgeLabel
	  */
	 public void addEdge(Label parentName, Label childName, Label edgeLabel) {
		 checkRep();
		 if (parentName != null && childName != null && edgeLabel != null) {
			 simGraph.addEdge(parentName, childName, edgeLabel);
		 }
		 checkRep();
	 }
	 
	 /**
	  * @modifies this
	  * @effects  adds an input value to Pipe named pipeName
	  */
	 public void injectInput(Label pipeName, Object value) {
		 checkRep();
		 if (pipeName != null && value != null) {
			 Pipe<Label> pipe = (Pipe<Label>) simGraph.getNodeObject(pipeName);
			 pipe.InjectValue(value);
			 simGraph.setNodeObject(pipeName, pipe);
		 }
		 checkRep();
	 }
	 
	/**
	 * @modifies none
	 * @effects  returns the Node's Object
	 * @returns  in case the node is found return the Node's Object
	 * 			 in case not the function returns null
	 */
	public Object getNodeElement (Label pipeName) {
		checkRep();
		if (pipeName != null) {
			return simGraph.getNodeObject(pipeName);
		}
		return null;
	}
	/**
	 * @modifies this
	 * @effects  simulate the pipes and filters for 1 timeSlice
	 */
	public void simulate() {
		checkRep();
		 List<Label> blackNodeList = simGraph.getBlackNodes();
		 List<Label> whiteNodeList = simGraph.getWhiteNodes();
		 
		 for (Label x : blackNodeList) {
			 Pipe<Label> newPipe = (Pipe<Label>) simGraph.getNodeObject(x);
			 newPipe.simulate(simGraph, timeSlice);
		 }
		 
		 for (Label x : whiteNodeList) {
			 Filter<Label> newFilter = (Filter<Label>) simGraph.getNodeObject(x);
			 newFilter.simulate(simGraph, timeSlice);
		 }
		 checkRep();
	}
	
	private void checkRep () {
		assert timeSlice > 0:
				"timeslice must be greater that 0";
		
		assert simGraph != null: 
				"simGraph must be valid";
		
	}
	
}
	 

