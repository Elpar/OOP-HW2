package homework2;

/*
 * Filter is an abstract generic class for a filter. 
 * The simulate function must be implemented by the inherited classes.
 * Filter will get inputs, process them and produce outputs.
 */
public abstract class Filter<Label> implements Simulatable<Label>{
	
	/* Abstraction Function :
	 * filter label represents an immutable generic class.
	 * filterDelay can be a non negative Delay time as delay supposed to be
	 * 0 or more.
	 */
	
	/* Representation Invariant :
		filterDelay >= 0;
	 */
	
	private Label 	filterLabel;
	private double  filterDelay;
	
	/**
	 * @requires filterLabel
	 * @modifies this
	 * @effects  Constructs a new filter
	 */
	public Filter(Label filterLabel) {
		this.filterLabel = filterLabel;
		this.filterDelay = 0;
		checkRep();
		
	}
	
	/**
	 * @modifies none
	 * @effects  returns the filter's Delay time
	 */
	public double getFilterDelay() {
		checkRep();
		return this.filterDelay;
	}
	
	/**
	 * @modifies this
	 * @effects  set the filter's Delay time
	 */
	public void setFilterdelay(int filterDelay) {
		checkRep();
		if (filterDelay > 0) {
			this.filterDelay = filterDelay;
		}
		checkRep();
	}
	
	/**
	 * @modifies none
	 * @effects  returns the filter's Label
	 */
	public Label getFilterLabel() {
		checkRep();
		return this.filterLabel;
	}
	
	/**
	 * @requires timeSlice > 0
	 * @modifies this, graph
	 * @effects Simulates this pipe or filter in a system modeled by graph
	 * 			for the length of time given by timeSlice seconds.
	 */
	@Override
	public abstract void simulate(BipartiteGraph<Label> graph, double timeSlice);
	
	 /*
     * Checks if the representation invariant is being violated
     * @throws AssertionError if representation invariant is violated. 
     */
    private void checkRep() {
    	assert filterDelay >= 0:
    		"Filter delay can not be negative";
    }

}