package homework2;

/*
 * Linker class - a class built for Node and biPartiteGraph.
 * The class is generic with <Label>. It contains a object and edge labels.
 */
public class Linker<Label> {

	/* Representation Invariant :
	 * 	Label should be immuatble class
	 */
	
	private Label objectLabel;
	private Label edgeLabel;
	
	/**
	 * @requires objectLabel != null edgeLabel != null
	 * @modifies this
	 * @effects  Constructs a new Linker
	 */
	public Linker(Label objectLabel, Label edgeLabel) {
		this.objectLabel = objectLabel;
		this.edgeLabel   = edgeLabel; 
		checkRep();
	}
	
	/**
	 * @modifies none
	 * @effects  get the Linker's Object Label
	 */
	public Label getObjectLabel() {
		checkRep();
		return this.objectLabel;
	}
	
	/**
	 * @modifies none
	 * @effects  get the Linker's Edge Label
	 */
	public Label getEdgeLabel() {
		checkRep();
		return this.edgeLabel;
	}
	
	private void checkRep() {
		assert objectLabel != null:
				"Linker must be propertly defined";
		
		assert edgeLabel != null:
				"Linker must be propertly defined";
	}
}
