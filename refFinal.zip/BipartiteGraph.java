package homework2;
import java.util.ArrayList;
import java.util.List;


/*
 * BipartiteGraph: The bipartite graph is a directed generic graph with 2 
 * different kinds of nodes: Black nodes and White nodes. 
 * The bipartite graph is a generic class. It can be initialized with any
 * class which will describe it's 'label'. Also, the interface of bipartite
 * graph enables to save any elements data in the nodes.
 */

public class BipartiteGraph<Label> {
	/* Abstraction Function :
	 * The bipartite graph is a directed generic graph with 2 different kinds 
	 * of nodes: Black nodes and White nodes. 
	 * The nodes are saved in a List which contains objects called "Node" as 
	 * described in the Node class.
	 * The bipartite graph is a generic class. It can be initialized with any
	 * class which will describe it's 'label'. Also, the interface of bipartite
	 * graph enables to save any elements data in the nodes.
	 * This graph should be used under the following assumptions:
	 * 		-Having nodes a,b . There won't be more than one directed edge (a,b), (b,a)
	 * 		 Though, one edge from both kind can exist ((a,b), (b,a)).
	 * 		-All outgoing edges from a node will be with different labels. Same
	 * 		 for incoming edges. The same label for an incoming and outgoing edge
	 * 		 for the same node is allowed.
	 * 		-The graph interface returns enum status for most of the methods:
				ERROR_NODE_EXISTS,
				NODE_ADD_SUCCESS,
				EDGE_ADD_SUCCESS,
				ERROR_NULL_INPUT,
				ERROR_PARENT_NOT_EXIST,
				ERROR_CHILD_NOT_EXIST,
				ERROR_SAME_COLORS
	 */
	
	/* Representation Invariant :
		-Same node can not be inserted more than one time.
		-A node can not be connected to another node with the same color.
		-An edge should be added between existed nodes in the graph.
		-The label class should be immutable.
	 */
	
	private List<Node<Label>> nodes = new ArrayList<Node<Label>>();
	
	/**
    * @effects true if nodeLabel exists in graph and false otherwise (if null
    * 	returns false.
    */
	private boolean isNodeExists(Label nodeLabel) {
		//color is not relevant. Comparision done by Label of node.
		if (nodeLabel == null) return false;
		Node<Label> newNode = new Node<Label>(nodeLabel, NodeColor.WHITE);
		if (Contains(newNode)) {
			return true;
		}
		else {
			return false;
		}		
	}
	
	/**
    * @effects: return the Node labeled 'nodeLabel'. If not found return null.
    */	
	private Node<Label> getNode(Label nodeLabel) {
		if (nodeLabel == null) return null;
		
		for (Node<Label> x : nodes) {
			if ( x.getNodeLabel().equals(nodeLabel)) {
				return x;
			}
		}
		return null;	
	}
	
	 /**
     * @effects: return the Node Object of the node labeled nodelabeled. 
     * If not found return null.
     */	
	public Object getNodeObject(Label nodeLabel) {
		checkRep();
		if (nodeLabel == null) return null;
		
		for (Node<Label> x : nodes) {
			if (x.getNodeLabel().equals(nodeLabel)) {
				return x.getNodeObject();
			}
		}
		checkRep();
		return null;	
	}
	
	
	/**
	* @modifies: this
	* @effects: inject object to the node labeled "nodeLabel"
	*/	
	public void setNodeObject(Label nodeLabel, Object object) {
		checkRep();
		for (Node<Label> x : nodes) {
			if (x.getNodeLabel().equals(nodeLabel)) {
				x.setNodeObject(object);
				checkRep();
				return;
			}
		}
	}
	
	/**
    * @modifies: this
    * @effects: Insert a black node to the graph. Return:
    * 	ERROR_NULL_INPUT - for null input
    *   ERROR_NODE_EXISTS - if node already exist
    *   NODE_ADD_SUCCESS - if node added successfully
    */	
	public Status addBlackNode(Label nodeLabel) {
		checkRep();
		if (nodeLabel == null) {
			return Status.ERROR_NULL_INPUT;
		}
		
		if (isNodeExists(nodeLabel) == true) {
			return Status.ERROR_NODE_EXISTS;
		}
		
		else {
			nodes.add(new Node<Label>(nodeLabel, NodeColor.BLACK));
			checkRep();
			return Status.NODE_ADD_SUCCESS;
		}
	}
	
	
	
	
	/**
    * @modifies: this
    * @effects: Insert a black node with it's object to the graph. Return:
    * 	ERROR_NULL_INPUT - for null input
    *   ERROR_NODE_EXISTS - if node already exist
    *   NODE_ADD_SUCCESS - if node added successfully
    */	
	public Status addBlackNodeWithObject(Label nodeLabel, Object object) {
		checkRep();
		if (nodeLabel == null) {
			return Status.ERROR_NULL_INPUT;
		}
		
		if (isNodeExists(nodeLabel) == true) {
			return Status.ERROR_NODE_EXISTS;
		}
		
		else {
			Node<Label> newNode = new Node<Label>(nodeLabel, NodeColor.BLACK);
			newNode.setNodeObject(object);
			nodes.add(newNode);
			checkRep();
			return Status.NODE_ADD_SUCCESS;
		}
	}
	
	/**
    * @modifies: this
    * @effects: Insert a white node to the graph. Return:
    * 	ERROR_NULL_INPUT - for null input
    *   ERROR_NODE_EXISTS - if node already exist
    *   NODE_ADD_SUCCESS - if node added successfully
    */	
	public Status addWhiteNode(Label nodeLabel) {
		checkRep();
		if (nodeLabel == null) {
			return Status.ERROR_NULL_INPUT;
		}
		
		if (isNodeExists(nodeLabel) == true) {
			return Status.ERROR_NODE_EXISTS;
		}
		
		else {
			nodes.add(new Node<Label>(nodeLabel, NodeColor.WHITE));
			checkRep();
			return Status.NODE_ADD_SUCCESS;
		}
	}
	
	
	/**
    * @modifies: this
    * @effects: Insert a white node with it's object to the graph. Return:
    * 	ERROR_NULL_INPUT - for null input
    *   ERROR_NODE_EXISTS - if node already exist
    *   NODE_ADD_SUCCESS - if node added successfully
    */	
	public Status addWhiteNodeWithObject(Label nodeLabel,  Object object) {
		checkRep();
		if (nodeLabel == null) {
			return Status.ERROR_NULL_INPUT;
		}
		
		if (isNodeExists(nodeLabel) == true) {
			return Status.ERROR_NODE_EXISTS;
		}
		
		else {
			Node<Label> newNode = new Node<Label>(nodeLabel,NodeColor.WHITE);
			newNode.setNodeObject(object);
			nodes.add(newNode);
			checkRep();
			return Status.NODE_ADD_SUCCESS;
		}
	}
	
	
	/**
    * @modifies: this
    * @effects: adding a labeled edge between parent to child. Return:
    * 	ERROR_NULL_INPUT - for null input
    *   ERROR_CHILD_NOT_EXIST - if child not exist
    *   ERROR_PARENT_NOT_EXIST - if parent not exist
    *   EDGE_ADD_SUCCESS - if edge added successfully
    */	
	public Status addEdge(Label parentName, Label childName, Label edgeLabel) {
		if (parentName == null || childName == null || edgeLabel == null) {
			checkRep();
			return Status.ERROR_NULL_INPUT;
		}
		
		if (isNodeExists(childName) == false) {
			return Status.ERROR_CHILD_NOT_EXIST;
		}
		
		if (isNodeExists(parentName) == false) {
			return Status.ERROR_PARENT_NOT_EXIST;	
		}
		
		Node<Label> parent = getNode(parentName);
		Node<Label> child  = getNode(childName);
		
		if (parent.getColor() == child.getColor()) {
			return Status.ERROR_SAME_COLORS;
		}
		
		parent.addChild(childName, edgeLabel);
		child.addParent(parentName, edgeLabel);
		checkRep();
		return Status.EDGE_ADD_SUCCESS;
		
	}
	
	/**
    * @modifies: this
    * @effects: removing a labeled edge between parent to child. Return:
    * 	ERROR_NULL_INPUT - for null input
    *   ERROR_CHILD_NOT_EXIST - if child not exist
    *   ERROR_PARENT_NOT_EXIST - if parent not exist
    *   EDGE_REMOVE_SUCCESS - if edge added successfully
    */	
	public Status removeEdge(Label parent, Label child, Label edgeLabel) {
		if (parent == null || child == null || edgeLabel == null) {
			checkRep();
			return Status.ERROR_NULL_INPUT;
		}
		
		if (isNodeExists(child) == false) {
			return Status.ERROR_CHILD_NOT_EXIST;
		}
		
		if (isNodeExists(parent) == false) {
			return Status.ERROR_PARENT_NOT_EXIST;	
		}
		Node<Label> parentNode = getNode(parent);
		Node<Label> childNode = getNode(child);
		parentNode.removeChild(child, edgeLabel);
		childNode.removeParent(parent, edgeLabel);
		return Status.EDGE_REMOVE_SUCCESS;
	}
	
	
	/**
	* @requires: color won't be null.
    * @effects: return a list of all nodes with the color 'color'.
    */	
	private List<Label> getNodesListByColor(NodeColor color) {
		List<Label> newList = new ArrayList<Label>();
		
		for (Node<Label> node : nodes) {
			if (node.getColor() == color) {
				newList.add(node.getNodeLabel());
			}
		}
		return newList;
	}
	
	
	/**
    * @effects: return a list of all nodes with the color 'BLACK'.
    */	
	public List<Label> getBlackNodes() {
		checkRep();
		return getNodesListByColor(NodeColor.BLACK);
	}
	
	/**
    * @effects: return a list of all nodes with the color 'WHITE'.
    */	
	public List<Label> getWhiteNodes() {
		checkRep();
		return getNodesListByColor(NodeColor.WHITE);
	}
	
	
	/**
    * @effects: return a list of all parent nodes of child node. If child
    * not exist return null.
    */	
	public List<Label> getParentsNodes(Label childName) {
		checkRep();
		if (childName == null) {
			return null;
		}
		
		if (isNodeExists(childName) == false) {
			return null;
		}
		
		Node<Label> childNode = getNode(childName);
		checkRep();
		return childNode.getParentsNodes(childName);
	}
	
	/**
    * @effects: return a list of all children nodes of parent node. If parent
    * not exist return null.
    */	
	public List<Label> getChildrenNodes(Label parentName) {
		checkRep();
		if (parentName == null) {
			return null;
		}
		
		if (isNodeExists(parentName) == false) {
			return null;
		}
		
		Node<Label> parentNode = getNode(parentName);
		checkRep();
		return parentNode.getChildrenNodes(parentName);
	}
	
	
	/**
    * @effects: return the label of the child of 'parentName' node which is
    * connected by a specific edge labeled 'edgeLabel'.
    * if parent or label not exist, return null.
    */	
	public Label getChildByEdgeLabel(Label parentName, Label edgeLabel) {
		checkRep();
		if (parentName == null || edgeLabel == null) {
			return null;
		}
		
		if (isNodeExists(parentName) == false) {
			return null;
		}
		
		Node<Label> parent = getNode(parentName);
		checkRep();
		return parent.getChildByEdgeLabel(edgeLabel);
	}
	
	/**
    * @effects: return the label of the parent of 'childName' node which is
    * connected by a specific edge labeled 'edgeLabel'.
    * if child or label not exist, return null.
    */		
	public Label getParentByEdgeLabel(Label childName, Label edgeLabel) {
		checkRep();
		if (childName == null || edgeLabel == null) {
			return null;
		}
		
		if (isNodeExists(childName) == false) {
			return null;
		}
		
		Node<Label> parent = getNode(childName);
		checkRep();
		return parent.getParentByEdgeLabel(edgeLabel);
	}
	
	/**
    * @effects: return true if node is contained in graph, false otherwise.
    **/
	public boolean Contains (Node<Label> node) {
		checkRep();
		if (node == null) {
			return false;
		}
		
		for (Node<Label> x : nodes) {
			if ( x.getNodeLabel().equals(node.getNodeLabel())) {
				checkRep();
				return true;
			}
		}
		checkRep();
		return false;
	}
	
//	/**
//    * @effects: returns a list with all objects of nodes in the graph
//    **/
//	public List<Object> getListNodeObject () {
//		checkRep();
//		List<Object> newList = new ArrayList<Object>();
//		
//		for (Node<Label> x : nodes) {
//				newList.add(x);
//			}
//		checkRep();
//		return newList;
//	}
	
	/**
    * @effects: get a color of node by it's label. If not found return null
    **/
	private NodeColor getColorByLabel (Label nodeLabel) {
		for (Node<Label> x : nodes) {
			if ( x.getNodeLabel().equals(nodeLabel)) {
				return x.getColor();
			}
		}
		return null;
	}

	
    private void checkRep() {
    	if (nodes.size() > 0) {
	    	for (Node<Label> current : nodes) {
				int nodeCnt = 0;
	    		for (Node<Label> node : nodes) {
					if (current.getNodeLabel().equals( node.getNodeLabel())) {
						nodeCnt++;
					}
				}
	    		assert (nodeCnt == 1) :
	    			"Error: Node '" + current.getNodeLabel().toString() 
	    			+ "' appeared more than once";
	    	}
	    	
	    	for (Node<Label> current : nodes) {
	    		Node<Label> childNode = getNode(current.getNodeLabel());

	    		List<Label> parentLabelsList = childNode.getParentsNodes(current.getNodeLabel());
	    		
	    		// List<Label> parentLabelsList = getParentsNodes(current.getNodeLabel());
	    		 if (parentLabelsList.size() > 0) {
		    		 for (Label label : parentLabelsList) {
		    			 assert (!current.getColor().equals(getColorByLabel(label))):
		    				"Error: incoming edge is in same color as: " + 
		    					 current.getNodeLabel().toString(); 	
		    		 }
	    		 }
	    		 Node<Label> parentNode = getNode(current.getNodeLabel());
	    		 List<Label> childrenLabelsList = parentNode.getChildrenNodes(current.getNodeLabel());
	    		 
	    		//List<Label> childrenLabelsList = getChildrenNodes(current.getNodeLabel());
	    		if (childrenLabelsList.size() > 0) {
		    		for (Label label : childrenLabelsList) {
		    			assert (!current.getColor().equals(getColorByLabel(label))):
		    				"Error: outgoing edge is in same color as: " + 
		    					current.getNodeLabel().toString(); 
							
					}
	    		}
	    	}
	 
	   }
    }
    	  	
}
