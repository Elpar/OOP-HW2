package homework2;

import java.util.List;

/*
 * Plusfilter is a adder filter, inherited from the filter class.
 */

public class PlusFilter extends Filter<String> implements Simulatable<String> {

	/* Abstraction Function :
	 * PLus filter label represents a String class.
	 * filterDelay of the PLus will be 1.
	 */
	
	/* Representation Invariant :
	 *	The filter can be connected to unlimited input pipes and one output pipe.
	 */
	
	
	private int filterOutput; 
	
	/**
	 * @requires filterLabel != null
	 * @modifies this
	 * @effects  Constructs a new Plusfilter
	 */
	public PlusFilter(String filterLabel) {
		super(filterLabel);
		this.filterOutput = 0;
		setFilterdelay(1);
	}
	
	/**
	 * @requires timeSlice > 0
	 * @modifies this, graph
	 * @effects Simulates this pipe or filter in a system modeled by graph
	 * 			for the length of time given by timeSlice seconds.
	 */
	@Override
	public void simulate(BipartiteGraph<String> graph, double timeSlice) {
		
		if(graph.getParentsNodes(getFilterLabel()).size() != 1)
			throw new IllegalArgumentException("number of output pipes must be 1");
		
		if (graph != null) {
			filterOutput = 0;
			List<String> parentsList 	= graph.getParentsNodes(getFilterLabel());
			List<String> childrenList 	= graph.getChildrenNodes(getFilterLabel());
		
			for (double timeElapsed = 0; timeElapsed + getFilterDelay() <= timeSlice; 
						timeElapsed=+getFilterDelay()) {
			
				for (String x : parentsList) {
						IntPipe newPipe = (IntPipe) graph.getNodeObject(x);
						filterOutput += (Integer)newPipe.removeLastElement();
				}
		
				for (String x : childrenList) {
					IntPipe newPipe = (IntPipe) graph.getNodeObject(x);
					newPipe.InjectValue(filterOutput);	
				}
			}
		}
	}
	

}
