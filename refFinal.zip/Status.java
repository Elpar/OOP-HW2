package homework2;

/*An enum class for status from graph*/
public enum Status {
						ERROR_NODE_EXISTS,
						NODE_ADD_SUCCESS,
						EDGE_ADD_SUCCESS,
						ERROR_NULL_INPUT,
						ERROR_PARENT_NOT_EXIST,
						ERROR_NODE_NOT_EXIST,
						ERROR_CHILD_NOT_EXIST,
						ERROR_SAME_COLORS,
						EDGE_REMOVE_SUCCESS,
						NODE_REMOVE_SUCCESS,
						ERROR_REMOVE_NOT_EXIST
};

