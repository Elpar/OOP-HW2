package homework2;

/* An Enum for differentiating between the black and white Nodes*/
public enum NodeColor {BLACK, WHITE};
