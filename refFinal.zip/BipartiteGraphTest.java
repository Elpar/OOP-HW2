package homework2;

import static org.junit.Assert.*;

import org.junit.Test;


/**
 * BipartiteGraphTest contains JUnit block-box unit tests for BipartiteGraph.
 */
public class BipartiteGraphTest {
	
	@Test
    public void testExample() {
        BipartiteGraphTestDriver driver = new BipartiteGraphTestDriver();
        
        //create a graph
        driver.createGraph("graph1");
        driver.createGraph("graph2");
        
        //add a pair of nodes
        driver.addBlackNode("graph1", "n1");
        driver.addWhiteNode("graph1", "n2");
        
        //add an edge
        driver.addEdge("graph1", "n1", "n2", "edge");
        
        //check neighbors
        assertEquals("wrong black nodes", "n1", driver.listBlackNodes("graph1"));
        assertEquals("wrong white nodes", "n2", driver.listWhiteNodes("graph1"));
        assertEquals("wrong children"	, "n2", driver.listChildren  ("graph1", "n1"));
        assertEquals("wrong children"	, ""  , driver.listChildren  ("graph1", "n2"));
        assertEquals("wrong parents"	, ""  , driver.listParents   ("graph1", "n1"));
        assertEquals("wrong parents"	, "n1", driver.listParents   ("graph1", "n2"));
    }	
	
    @Test
    public void testUniqeElements() {
    	BipartiteGraph<String> graph = new BipartiteGraph<String>();
    	graph.addBlackNode("A");
    	assertEquals("wrong identical nodes", Status.ERROR_NODE_EXISTS, graph.addBlackNode("A"));
    	assertEquals("wrong identical nodes", Status.ERROR_NODE_EXISTS, graph.addWhiteNode("A"));
    	
    	graph.addWhiteNode("B");
    	assertEquals("success adding edge", Status.EDGE_ADD_SUCCESS, graph.addEdge("A", "B", "A"));
    	assertEquals("success adding edge", Status.EDGE_ADD_SUCCESS, graph.addEdge("B", "A", "A"));
    	
    }
    
    @Test
    public void testElementsNotExists() {
    	BipartiteGraph<String> graph = new BipartiteGraph<String>();
    	graph.addBlackNode("A");    	
    	graph.addWhiteNode("B");
   
    	assertEquals("Failed child not exist", Status.ERROR_CHILD_NOT_EXIST, graph.addEdge("A", "C", "A"));
    	assertEquals("Failed parent not exist", Status.ERROR_PARENT_NOT_EXIST, graph.addEdge("C", "A", "A"));
  
    }
    
    @Test
    public void testSameColor() {
    	BipartiteGraph<String> graph = new BipartiteGraph<String>();
    	graph.addBlackNode("A");    	
    	graph.addBlackNode("B");
   
    	assertEquals("Error - edge between same colors", Status.ERROR_SAME_COLORS, graph.addEdge("A", "B", "A"));
    	assertEquals("Error - edge between same colors", Status.ERROR_SAME_COLORS, graph.addEdge("B", "A", "A"));
    }

    @Test
    public void testNullInput() {
    	BipartiteGraph<String> graph = new BipartiteGraph<String>();
    	assertEquals("Error handling null input", Status.ERROR_NULL_INPUT, graph.addBlackNode(null));    	
    	graph.addBlackNode("A");
    	assertEquals("Error Error handling null input", Status.ERROR_NULL_INPUT, graph.addEdge("A", null, "A"));
    	assertEquals("Error Error handling null input", Status.ERROR_NULL_INPUT, graph.addEdge("A", "A", null));
    	assertEquals("Error Error handling null input", Status.ERROR_NULL_INPUT, graph.addEdge(null, "A", "A"));
    }

	@Test
	public void testGetSetNodeObject() {
		BipartiteGraph<String> graph = new BipartiteGraph<String>();
		Integer newInt = new Integer(5);
		graph.addBlackNodeWithObject("A", newInt);
		assertEquals("Error getting existing node",newInt ,graph.getNodeObject("A"));
		assertEquals("Error getting existing node",null ,graph.getNodeObject("B"));
		assertEquals("Error getting existing node",null ,graph.getNodeObject(null));
		
		graph.setNodeObject("A", new Integer(4));
		assertEquals("Error getting existing node",new Integer(4) ,graph.getNodeObject("A"));
	}
	
	@Test
	public void testGetChildParentByEdgeLabel() {
		BipartiteGraph<String> graph = new BipartiteGraph<String>();
		graph.addBlackNode("hello");
		graph.addWhiteNode("white");
		graph.addEdge("hello", "white", "edge");
		assertEquals("Error wrong child", "white", graph.getChildByEdgeLabel("hello", "edge"));
		assertEquals("Error wrong parent", "hello", graph.getParentByEdgeLabel("white", "edge"));
		assertNull("Error cno children", graph.getChildByEdgeLabel("white", "edge"));
	}
	
	@Test
	public void testRemoveEdge() {
		BipartiteGraph<String> graph = new BipartiteGraph<String>();
		graph.addBlackNode("hello");
		graph.addWhiteNode("white");
		graph.addEdge("hello", "white", "edge");
		assertEquals("Error remove edge", Status.EDGE_REMOVE_SUCCESS, graph.removeEdge("hello", "white", "edge"));
	}
	
}