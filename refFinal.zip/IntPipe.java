package homework2;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;

/*
 * IntPipe is a pipe for transferring integer numbers. It will have a delay of
 * 1 timeSlice and an unlimited capacity.  
 * It inherits Pipe class
 */
public class IntPipe extends Pipe<String> implements Simulatable<String>{
	
	
	/* Abstraction Function :
	 * pipeDelay will be 1 always.
	 * the input pending lists and the output ready lists will have an unlimited
	 * capacity
	
	/* Representation Invariant :
	 * pipeDelay == 1;
	 * pipeCapacity >= -1
	 */
	
	private Queue<Object> Pending_InjectedList 	= null;
	private Queue<Object> Ready_InjectedList 	= null;
	
	/**
	 * @requires pipeLabel != null
	 * @modifies this
	 * @effects  Constructs a new IntPipe
	 */
	public IntPipe(String pipeLabel) {
		super(pipeLabel);
		super.setPipeDelay(1);
		this.Pending_InjectedList 	= new LinkedList<Object>();
		this.Ready_InjectedList		= new LinkedList<Object>();
		checkRep();
	}
	
	
	 /**
	  * @modifies this
	  * @effects  adds an input value to the pipe
	  */
	public void InjectValue(Object value) {
		checkRep();
		Pending_InjectedList.add(value);
		checkRep();
	}
	
	 /**
	  * @modifies none
	  * @effects  get the list of Objects currently in the pipe
	  */
	public Queue<Object> getPipeElements() {
		checkRep();
		Queue<Object> elements = new LinkedList<Object>();
		
		Iterator<Object> it = Ready_InjectedList.iterator();
		while (it.hasNext()) {
			elements.add(it.next());
		}
		
		it = Pending_InjectedList.iterator();
		while (it.hasNext()) {
			elements.add(it.next());
		}
		
		checkRep();
		return elements;
	}
	
	/**
	 * @modifies none
	 * @effects  get the last element that is ready in pipe but don't remove it
	 */
	public Object getLastElement () {
		checkRep();
		if (Ready_InjectedList.size() == 0) {
			return 0;
		}
		else {
			return Ready_InjectedList.peek();
		}
	}
	
	/**
	 * @modifies this
	 * @effects  get the last element that is ready in pipe and remove it
	 */
	public Object removeLastElement() {
		checkRep();
		if (Ready_InjectedList.size() == 0) {
			return 0;
		}
		else {
			return this.Ready_InjectedList.poll();
		}
			
	}
	
	/**
	 * @throws Exception 
	 * @requires timeSlice > 0
	 * @modifies this, graph
	 * @effects Simulates this pipe or filter in a system modeled by graph
	 * 			for the length of time given by timeSlice seconds.
	 */
	@Override
	public void simulate(BipartiteGraph<String> graph, double timeSlice) {
		checkRep();
		if(graph == null) 
			throw new IllegalArgumentException("Graph cannot be null");
		
		if(timeSlice <= 0) 
			throw new IllegalArgumentException("timeslice must be greater then zero");
	
		if(graph.getChildrenNodes(getLabel()).size() > 1) 
			 throw new IllegalArgumentException("IntPipe must have only one child");
		
			for (double timeElapsed = 0; timeElapsed + getPipeDelay() <= timeSlice; 
						timeElapsed += getPipeDelay()) {
			
				for (Object x : Pending_InjectedList) {
					Ready_InjectedList.add(x);
				}
				Pending_InjectedList.clear();
			}
		checkRep();
	}
	
	private void checkRep() {
		assert Pending_InjectedList != null:
				"Pending injected list must be valid";
		
		assert Ready_InjectedList != null:
				"Ready injected list must be valid";
	}

}
