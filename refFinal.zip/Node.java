package homework2;
import java.util.Iterator;
import java.util.List; 
import java.util.ArrayList; 

/*
 * The Node class is a gnerics class which describes a node of bipartiteGraph.
 * it Contains a label of the node, the object of the node, color, and lists
 * of parents and children.
 */

public class Node<Label> {
	/* Abstraction Function :
	 * The node will contain a nodeLabel with object of a generic type Label.
	 * The node will contain an Object which will be the node's object.
	 * The node will have a black/white color.
	 * The node will contain lists of all parents and all children nodes labels.
	 */
	
	/* Representation Invariant :
		-The label class should be immutable.
		-the color can be BLACK or WHITE according to the enum NodeColor.
	 */
	
	private Label 				nodeLabel; 
	private Object 				nodeObject; 
	private NodeColor 			color;
	private List<Linker<Label>> parents;
	private List<Linker<Label>> children;
	private List<Label> 		parentsLabels; 		//for returning list of labels in O(1)
	private List<Label> 		childrenLabels; 	//for returning list of labels in O(1)

	
	
	/** 
	* @modifies - this
    * @effects constructor - initialize the object with given label and color.
    * Also initiate new lists for parents and children.
    */ 
	public Node (Label nodeLabel, NodeColor color) {
		this.color 		 	= color;
		this.nodeLabel  	= nodeLabel;
		this.nodeObject	 	= null;
		this.parents 	 	= new ArrayList<Linker<Label>>();
		this.children 	 	= new ArrayList<Linker<Label>>();
		this.parentsLabels 	= new ArrayList<Label>();
		this.childrenLabels = new ArrayList<Label>();
		checkRep();
	}
	
	/** 
	* @modifies - this
    * @effects constructor - initialize the object with given label, object
    * and color.
    * Also initiate new lists for parents and children.
    */
	public Node (Label nodeLabel, NodeColor color, Object nodeObject) {
		this.color 		 	= color;
		this.nodeLabel   	= nodeLabel;
		this.nodeObject  	= nodeObject;
		this.parents 	 	= new ArrayList<Linker<Label>>();
		this.children 	 	= new ArrayList<Linker<Label>>();
		this.parentsLabels 	= new ArrayList<Label>();
		this.childrenLabels = new ArrayList<Label>();
		checkRep();
	}
	
	/** 
	* @requires - child is not in the same color as this
	* @modifies - this
    * @effects add a child to the current node's childrenList with the edge
    * labeled 'edgeName'. If inputs are null do nothing.
    */
	public void addChild(Label childName, Label edgeName) {
		checkRep();
		if (childName == null || edgeName == null) {
			return;
		}
		Linker<Label> newChild = new Linker<Label>(childName, edgeName);
		this.children.add(newChild);
		childrenLabels.add(newChild.getObjectLabel());
		checkRep();
	}
	
	/**
	* @modifies - this
    * @effects remove an edge between this and child
    * labeled 'edgeName'. If inputs are null do nothing.
    */
	public void removeChild(Label childName, Label edgeName) {
		checkRep();
		if (childName == null || edgeName == null) {
			return;
		}
		
		boolean isChildExist = false;
		for (Linker<Label> x : this.children) {
			if (x.getObjectLabel().equals(childName) ) {
				isChildExist = true;
				break;
			}
		}
		if (isChildExist == true) {
			Linker<Label> Child = new Linker<Label>(childName, edgeName);
			this.children.remove(Child);
			childrenLabels.remove(childName);
		}
		checkRep();
	}
	
	
	
	/** 
	* @requires - parent is not in the same color as this
	* @modifies - this
    * @effects add a parent to the current node's parentsList with the edge
    * labeled 'edgeName'. If inputs are null do nothing.
    */
	public void addParent(Label parentName, Label edgeName) {
		checkRep();
		if (parentName == null || edgeName == null) {
			return;
		}
		Linker<Label> newParent = new Linker<Label>(parentName, edgeName);
		this.parents.add(newParent);
		parentsLabels.add(newParent.getObjectLabel());
		checkRep();
	}
	
	/**
	* @modifies - this
    * @effects remove an edge between this and parent
    * labeled 'edgeName'. If inputs are null do nothing.
    * */
	public void removeParent(Label parentName, Label edgeName) {
		checkRep();
		if (parentName == null || edgeName == null) {
			return;
		}
		boolean isEdgeAndParentExist = false;
		for (Linker<Label> x : this.parents) {
			if (x.getObjectLabel().equals(parentName)) {
				isEdgeAndParentExist = true;
				break;
			}
		}
		if (isEdgeAndParentExist == true) {
			Linker<Label> Parent = new Linker<Label>(parentName, edgeName);
			this.children.remove(Parent);
			childrenLabels.remove(Parent.getObjectLabel());
		}
	
		checkRep();
	}
	
	/** 
    * @effects return list of parents nodes in O(1)
    */
	public List<Label> getParentsNodes(Label childName) {
		return parentsLabels;
	}
	
	/** 
    * @effects return list of children nodes in O(1)
    */
	public List<Label> getChildrenNodes(Label parentName) {
		return childrenLabels;
	}
	
	/** 
    * @effects return a child of a node by edge label and if not exists return 
    * null
    */
	public Label getChildByEdgeLabel(Label edgeLabel) {
		checkRep();
		return findNodeByEdgeLabel(children, edgeLabel);
	}
	
	/** 
    * @effects return a parent of a node by edge label and if not exists return 
    * null
    */
	public Label getParentByEdgeLabel(Label edgeLabel) {
		checkRep();
		return findNodeByEdgeLabel(parents, edgeLabel);
	}
	
	/** 
    * @effects return the color of the node
    */
	public NodeColor getColor() {
		checkRep();
		return this.color;
	}
	
	/** 
    * @effects return the label of the node
    */
	public Label getNodeLabel() {
		checkRep();
		return this.nodeLabel;
	}
	
	/** 
    * @effects return the object of the node
    */
	public Object getNodeObject() {
		checkRep();
		return this.nodeObject;
	}
	
	/** 
    * @modifies - this 
    * @effects - return the object of the node
    */	
	public void setNodeObject(Object nodeObject) {
		checkRep();
		this.nodeObject = nodeObject;
		checkRep();
	}
	
	/** 
    * @effects return a node label from a linker lists by input of edge label 
    * and if not exists return null
    */
	private Label findNodeByEdgeLabel (List<Linker<Label>> nodeList, Label edgeLabel) {
	      
		Iterator<Linker<Label>> itr = nodeList.iterator();
	
		while(itr.hasNext()) {
			Linker<Label> currentLinker = itr.next();
			if (currentLinker.getEdgeLabel().equals(edgeLabel)) 
				return currentLinker.getObjectLabel();
		}
		return null;
	}
	
	 /*
     * Checks if the representation invariant is being violated
     * @throws AssertionError if representation invariant is violated. 
     */
    private void checkRep() {
    	assert (this.color.equals(NodeColor.WHITE) || this.color.equals(NodeColor.BLACK)):
    		"Error: node's color is not possible";
    }

	
}
