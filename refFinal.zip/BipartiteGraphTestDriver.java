package homework2;

import java.util.*;

/**
 * This class implements a testing driver for BipartiteGraph. The driver
 * manages BipartiteGraphs whose nodes and edges are Strings.
 */
public class BipartiteGraphTestDriver {

    private Map<String, BipartiteGraph<String>> graphs;
    
    /**
     * @modifies this
     * @effects Constructs a new test driver.
     */
    public BipartiteGraphTestDriver () {
    	
       this.graphs = new HashMap<String, BipartiteGraph<String>>();
    }

    
    /**
     * @requires graphName != null
     * @modifies this
     * @effects Creates a new graph named graphName. The graph is initially
     * 			empty.
     */
    public void createGraph(String graphName) {
        this.graphs.put(graphName, new BipartiteGraph<String>());
    }

    
    /**
     * @requires createGraph(graphName)
     *           && nodeName != null
     *           && neither addBlackNode(graphName,nodeName) 
     *                  nor addWhiteNode(graphName,nodeName)
     *                      has already been called on this
     * @modifies graph named graphName
     * @effects Adds a black node represented by the String nodeName to the
     * 			graph named graphName.
     */
    public void addBlackNode(String graphName, String nodeName) {
    	graphs.get(graphName).addBlackNode(nodeName);
    }

    
    /**
     * @requires createGraph(graphName)
     *           && nodeName != null
     *           && neither addBlackNode(graphName,nodeName) 
     *                  nor addWhiteNode(graphName,nodeName)
     *                      has already been called on this
     * @modifies graph named graphName
     * @effects Adds a white node represented by the String nodeName to the
     * 			graph named graphName.
     */
    public void addWhiteNode(String graphName, String nodeName) {
    	graphs.get(graphName).addWhiteNode(nodeName);
    }

    
    /**
     * @requires createGraph(graphName)
     *           && ((addBlackNode(parentName) && addWhiteNode(childName))
     *              || (addWhiteNode(parentName) && addBlackNode(childName)))
     *           && edgeLabel != null
     *           && node named parentName has no other outgoing edge labeled
     * 				edgeLabel
     *           && node named childName has no other incoming edge labeled
     * 				edgeLabel
     * @modifies graph named graphName
     * @effects Adds an edge from the node parentName to the node childName
     * 			in the graph graphName. The new edge's label is the String
     * 			edgeLabel.
     */
    public void addEdge(String graphName,
    					String parentName, String childName, 
                        String edgeLabel) {
    	graphs.get(graphName).addEdge(parentName, childName, edgeLabel);
    }

    
    /**
     * @requires createGraph(graphName)
     * @return a space-separated list of the names of all the black nodes
     * 		   in the graph graphName, in alphabetical order.
     */
    public String listBlackNodes(String graphName) {
    	//TODO: Implement this method
    	//TODO: sort the list
    	String blackNodesString = null;
    	List<String> blackNodesList = graphs.get(graphName).getBlackNodes();
    	Iterator<String> itr = blackNodesList.iterator();
    	int i = 0;
    	
    	Collections.sort(blackNodesList);
    	if (blackNodesList.size() == 0) {
    		blackNodesString = "";
    	}
    	
    	else {
        	while(itr.hasNext()) {

        		if (i < blackNodesList.size()-1) {
        			blackNodesString =  itr.next() +" ";
        		}
        		else {
        			blackNodesString =  itr.next();
        		}
        			
        	}
    	}	

    	return blackNodesString;
    	
    }

    
    /**
     * @requires createGraph(graphName)
     * @return a space-separated list of the names of all the white nodes
     * 		   in the graph graphName, in alphabetical order.
     */
    public String listWhiteNodes(String graphName) {
    	//TODO: Implement this method
    	String whiteNodesString = null;
    	List<String> whiteNodesList = graphs.get(graphName).getWhiteNodes();
    	int i = 0;
    	
    	Collections.sort(whiteNodesList);
    	Iterator<String> itr = whiteNodesList.iterator();
    	
    	if (whiteNodesList.size() == 0) {
    		whiteNodesString = "";
    	}
    	
    	else {
        	while(itr.hasNext()) {

        		if (i < whiteNodesList.size()-1) {
        			whiteNodesString =  itr.next() +" ";
        		}
        		else {
        			whiteNodesString =  itr.next();
        		}
        			
        	}
    	}	

    	return whiteNodesString;
    }

    
    /**
     * @requires createGraph(graphName) && createNode(parentName)
     * @return a space-separated list of the names of the children of
     * 		   parentName in the graph graphName, in alphabetical order.
     */
    public String listChildren(String graphName, String parentName) {
    	//TODO: Implement this method
    	
    	List<String> listChildrenList = graphs.get(graphName).getChildrenNodes(parentName);
    	String listChildrenString = null;
    	int i = 0;
    	
    	Collections.sort(listChildrenList);
    	Iterator<String> itr = listChildrenList.iterator();
    	
    	if (listChildrenList.size() == 0) {
    		listChildrenString = "";
    	}
    	
    	else {
        	while(itr.hasNext()) {

        		if (i < listChildrenList.size()-1) { 
        			listChildrenString =  itr.next() + " ";
        		}
        		else {
        			listChildrenString =  itr.next();
        		}
        			
        	}
    	}	

    	return listChildrenString;
    	
    }

    
    /**
     * @requires createGraph(graphName) && createNode(childName)
     * @return a space-separated list of the names of the parents of
     * 		   childName in the graph graphName, in alphabetical order.
     */
    public String listParents(String graphName, String childName) {
    	//TODO: Implement this method
    	List<String> listParentsList = graphs.get(graphName).getParentsNodes(childName);
    	String listParentsString = null;
    	int i = 0 ;
    	
    	Collections.sort(listParentsList);
    	Iterator<String> itr = listParentsList.iterator();
    	
    	if (listParentsList.size() == 0) {
    		listParentsString = "";
    	}
    	
    	else {
        	while(itr.hasNext()) {

        		if (i < listParentsList.size()-1) { 
        			listParentsString =  itr.next() + " ";
        		}
        		else {
        			listParentsString =  itr.next();
        		}
        			
        	}
    	}	

    	return listParentsString;
    	
    }

    
    /**
     * @requires addEdge(graphName, parentName, str, edgeLabel) for some
     * 			 string str
     * @return the name of the child of parentName that is connected by the
     * 		   edge labeled edgeLabel, in the graph graphName.
     */
    public String getChildByEdgeLabel(String graphName, String parentName,
    								   String edgeLabel) {
    	//TODO: Implement this method
    	return graphs.get(graphName).getChildByEdgeLabel(parentName, edgeLabel);
    	
    }

    
    /**
     * @requires addEdge(graphName, str, childName, edgeLabel) for some
     * 			 string str
     * @return the name of the parent of childName that is connected by the 
     * 		   edge labeled edgeLabel, in the graph graphName.
     */
    public String getParentByEdgeLabel(String graphName, String childName,
    									String edgeLabel) {
    	//TODO: Implement this method
    	return graphs.get(graphName).getParentByEdgeLabel(childName, edgeLabel);
    	
    }
}
