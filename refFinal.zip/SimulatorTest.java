package homework2;

import static org.junit.Assert.*;

import org.junit.Test;

public class SimulatorTest {

	@Test
    public void testWorkingPlusFilter() {
			
		SimulatorTestDriver newSimultor = new SimulatorTestDriver();
		
		newSimultor.createSimulator("sim1");
		
		newSimultor.addPipe("sim1", "Pipe1");
		newSimultor.addPipe("sim1", "Pipe2");
		newSimultor.addPipe("sim1", "Pipe3");
		newSimultor.addPipe("sim1", "Pipe4");
		newSimultor.addPipe("sim1", "Pipe5");
		newSimultor.addPipe("sim1", "Pipe6");
		
		newSimultor.addPlusFilter("sim1", "PlusFilter1");
		newSimultor.addPlusFilter("sim1", "PlusFilter2");
		
		newSimultor.addEdge("sim1", "Pipe1", "PlusFilter1", "1");
		newSimultor.addEdge("sim1", "Pipe2", "PlusFilter1", "2");
		newSimultor.addEdge("sim1", "Pipe3", "PlusFilter1", "3");
		
		newSimultor.addEdge("sim1", "PlusFilter1", "Pipe4", "4");
		newSimultor.addEdge("sim1", "PlusFilter2", "Pipe6", "7");
		
		newSimultor.addEdge("sim1", "Pipe4", "PlusFilter2", "5");
		newSimultor.addEdge("sim1", "Pipe5", "PlusFilter2", "6");
		
		newSimultor.injectInput("sim1", "Pipe1", 1);
		newSimultor.injectInput("sim1", "Pipe1", 1);
		newSimultor.injectInput("sim1", "Pipe1", 1);
		
		newSimultor.injectInput("sim1", "Pipe2", 2);
		newSimultor.injectInput("sim1", "Pipe2", 2);
		newSimultor.injectInput("sim1", "Pipe2", 2);
		
		newSimultor.injectInput("sim1", "Pipe3", 3);
		newSimultor.injectInput("sim1", "Pipe3", 3);
		newSimultor.injectInput("sim1", "Pipe3", 3);
		
		newSimultor.injectInput("sim1", "Pipe5", 5);
		newSimultor.injectInput("sim1", "Pipe5", 5);
		newSimultor.injectInput("sim1", "Pipe5", 5);
		
		assertEquals("mismatch in pipe's content", "1 1 1", newSimultor.listContents("sim1", "Pipe1"));
		assertEquals("mismatch in pipe's content", "2 2 2", newSimultor.listContents("sim1", "Pipe2"));
		assertEquals("mismatch in pipe's content", "3 3 3", newSimultor.listContents("sim1", "Pipe3"));
		assertEquals("mismatch in pipe's content", "5 5 5", newSimultor.listContents("sim1", "Pipe5"));
		
		newSimultor.simulate("sim1");
		newSimultor.simulate("sim1");
		assertEquals("mismatch in pipe's content", "11 5", newSimultor.listContents("sim1", "Pipe6"));
		
		newSimultor.simulate("sim1");
		assertEquals("mismatch in pipe's content", "11 11 5", newSimultor.listContents("sim1", "Pipe6"));
    }
	
	@Test
    public void testWorkingGCDfilter() {
		
		SimulatorTestDriver newSimultor3 = new SimulatorTestDriver();
		newSimultor3.createSimulator("sim3");
	
		newSimultor3.addPipe("sim3", "Pipe1");
		newSimultor3.addPipe("sim3", "Pipe2");
		newSimultor3.addPipe("sim3", "Pipe3");
	
		newSimultor3.addGCDFilter("sim3", "GCDFilter1");
	
		newSimultor3.addEdge("sim3", "Pipe1", "GCDFilter1", "a");
		newSimultor3.addEdge("sim3", "Pipe2", "GCDFilter1", "b");
	
		newSimultor3.addEdge("sim3", "GCDFilter1", "Pipe1", "a");
		newSimultor3.addEdge("sim3", "GCDFilter1", "Pipe2", "b");
		newSimultor3.addEdge("sim3", "GCDFilter1", "Pipe3", "gcd");
	
		newSimultor3.injectInput("sim3", "Pipe1", 12);
		newSimultor3.injectInput("sim3", "Pipe2", 6);
	
		newSimultor3.simulate("sim3");
		newSimultor3.simulate("sim3");
	
		assertEquals("mismatch in pipe's content", "6", newSimultor3.listContents("sim3", "Pipe3"));
	}
	
	@Test(expected = IllegalArgumentException.class)
	// case GCDfilter doesn't have enough children
    public void testGCDfilterException1() {
		
		SimulatorTestDriver newSimultor4 = new SimulatorTestDriver();
		newSimultor4.createSimulator("sim4");
	
		newSimultor4.addPipe("sim4", "Pipe1");
		newSimultor4.addPipe("sim4", "Pipe2");
		newSimultor4.addPipe("sim4", "Pipe3");
	
		newSimultor4.addGCDFilter("sim4", "GCDFilter1");
	
		newSimultor4.addEdge("sim4", "Pipe1", "GCDFilter1", "a");
		newSimultor4.addEdge("sim4", "Pipe2", "GCDFilter1", "b");
		
		newSimultor4.addEdge("sim4", "GCDFilter1", "Pipe1", "a");
		newSimultor4.addEdge("sim4", "GCDFilter1", "Pipe2", "b");
	
		newSimultor4.injectInput("sim4", "Pipe1", 12);
		newSimultor4.injectInput("sim4", "Pipe2", 6);
	
		newSimultor4.simulate("sim4");
	}
	
	@Test (expected = IllegalArgumentException.class)
	// case GCDfilter doesn't have enough parents
    public void testGCDfilterException2() {
		
		SimulatorTestDriver newSimultor4 = new SimulatorTestDriver();
		newSimultor4.createSimulator("sim4");
	
		newSimultor4.addPipe("sim4", "Pipe1");
		newSimultor4.addPipe("sim4", "Pipe2");
		newSimultor4.addPipe("sim4", "Pipe3");
	
		newSimultor4.addGCDFilter("sim4", "GCDFilter1");
	
		newSimultor4.addEdge("sim4", "Pipe1", "GCDFilter1", "a");
	
		newSimultor4.addEdge("sim4", "GCDFilter1", "Pipe1", "a");
		newSimultor4.addEdge("sim4", "GCDFilter1", "Pipe3", "gcd");
	
		newSimultor4.injectInput("sim4", "Pipe1", 12);
	
		newSimultor4.simulate("sim4");
	}
	
	@Test (expected = IllegalArgumentException.class)
	// case PlusFilter has to many parents
	public void testPlusFilterException1() {
		SimulatorTestDriver newSimultor4 = new SimulatorTestDriver();
		newSimultor4.createSimulator("sim4");
		
		newSimultor4.addPipe("sim4", "Pipe1");
		newSimultor4.addPipe("sim4", "Pipe2");
		newSimultor4.addPipe("sim4", "Pipe3");
		
		newSimultor4.addPlusFilter("sim4", "PlusFilter1");
		
		newSimultor4.addEdge("sim4", "Pipe1", "PlusFilter1", "a");
		
		newSimultor4.addEdge("sim4", "PlusFilter1", "Pipe2", "b");
		newSimultor4.addEdge("sim4", "PlusFilter1", "Pipe3", "c");
	
		newSimultor4.injectInput("sim4", "Pipe1", 12);
		
		newSimultor4.simulate("sim4");
	}
	
}
