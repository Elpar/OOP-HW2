package homework2;

import java.util.Queue;

/*
 * Pipe is an abstract generic class for a Pipe. 
 * The simulate function must be implemented by the inherited classes.
 * Pipe will get objects in order to send them to their next locations.
 * Pipe may have capacity with the maximum number of objects to contains.
 * If the pipe is full, It won't get any inputs until it will empty one of it's 
 * object.
 */
public abstract class Pipe<Label> implements Simulatable<Label>{
		
	/* Abstraction Function :
	 * pipeLabel should be an immutable class.
	 * pipeDelay can be a non negative Delay time as delay supposed to be
	 * 0 or more.
	 * pipeCapacity of -1 will be abstraction for unlimited capacity.
	 * Other number will be the capacity of the pipe
	 */
	
	/* Representation Invariant :
	 * pipeDelay >= 0
	 * pipeCapacity >= -1
	 */
	
	
	
	private	 Label 	  pipeLabel;
	private  double	  pipeDelay;
	private  int	  pipeCapacity; 	
	
	/**
	 * @requires pipeLabel != null
	 * @modifies this
	 * @effects  Constructs a new Pipe
	 */
	public Pipe(Label pipeLabel) {
		this.pipeLabel 		= pipeLabel;
		this.pipeCapacity	=	-1;
		this.pipeDelay		=	0;
		checkRep();
	}
	
	/**
	 * @modifies none
	 * @effects  get the pipe's Label
	 */
	public Label getLabel() {
		checkRep();
		return pipeLabel;
		
	}
	
	/**
	 * @modifies this
	 * @effects  set the pipe's delay time
	 */
	public void setPipeDelay (int pipeDelay) {
		checkRep();
		this.pipeDelay = pipeDelay;
		checkRep();
	}
	
	/**
	 * @modifies this
	 * @effects  set the pipe's capacity time
	 */
	public void setPipeCapacity (int pipeCapacity) {
		checkRep();
		this.pipeCapacity = pipeCapacity;
		checkRep();
	}
	
	/**
	 * @modifies none
	 * @effects  get the pipe's delay time
	 */
	public double getPipeDelay() {
		checkRep();
		return this.pipeDelay;
	}
	
	/**
	 * @modifies none
	 * @effects  get the pipe's capacity
	 */
	public int getPipeCapacity() {
		checkRep();
		return this.pipeCapacity;
	}
	
	 /**
	  * @modifies this
	  * @effects  adds an input value to the pipe
	  */
	public abstract void InjectValue(Object value);

	 /**
	  * @modifies none
	  * @effects  get the list of Objects currently in the pipe
	  */
	public abstract Queue<Object> getPipeElements();
	
	 /**
	  * @modifies this
	  * @effects  get the last element that is ready in pipe and remove it
	  */
	public abstract Object removeLastElement();
	
	 /**
	  * @modifies none
	  * @effects  get the last element that is ready in pipe but don't remove it
	  */
	public abstract Object getLastElement();
	
	/**
	 * @throws Exception 
	 * @requires timeSlice > 0
	 * @modifies this, graph
	 * @effects Simulates this pipe or filter in a system modeled by graph
	 * 			for the length of time given by timeSlice seconds.
	 */
	@Override
	public abstract void simulate(BipartiteGraph<Label> graph, double timeSlice); 
	
	private void checkRep() {
		assert pipeCapacity >= -1 :
			"pipe is full should remove at least one value before entring new values";
		
		assert pipeDelay >= 0 :
			"pipe ddelay cannot be negative";
			
	}
}
