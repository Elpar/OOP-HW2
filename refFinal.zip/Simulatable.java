package homework2;

/**
 * The Simulatable interface is implemented by each of the pipes and filters
 * in a pipe-and-filter simulation.
 */
public interface Simulatable<T> {

	/**
	 * @requires timeSlice > 0
	 * @modifies this, graph
	 * @effects Simulates this pipe or filter in a system modeled by graph
	 * 			for the length of time given by timeSlice seconds.
	 */
	public void simulate(BipartiteGraph<T> graph, double timeSlice);
}
